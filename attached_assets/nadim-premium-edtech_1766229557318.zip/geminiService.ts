
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export async function generatePremiumNote(topic: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate a detailed educational note for the topic: "${topic}". Include key concepts, bullet points, and a summary. Mark it as Premium Content.`,
      config: {
        systemInstruction: "You are a senior academic tutor specializing in simplified explanations of complex topics.",
        temperature: 0.7,
      }
    });
    return response.text || "Failed to generate note.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error generating content. Please check your API key.";
  }
}
