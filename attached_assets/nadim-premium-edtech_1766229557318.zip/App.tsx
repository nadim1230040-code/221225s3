
import React, { useState, useEffect, createContext, useContext, useMemo } from 'react';
import { HashRouter as Router, Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, BookOpen, MessageSquare, Settings, LogOut, 
  Gamepad2, ShoppingCart, FlaskConical, FileText, User as UserIcon,
  Crown, Lock, Plus, Trash2, ExternalLink, ChevronRight, 
  ShieldCheck, AlertCircle, Database, Image as ImageIcon, Video, 
  Type, CheckCircle2, BarChart3, Clock, DollarSign, PenTool
} from 'lucide-react';
import { SubscriptionTier, User, AppSettings, ChatMessage, MCQQuestion, Note, MCQOption, DurationType } from './types';
import { generatePremiumNote } from './geminiService';

const ADMIN_EMAILS = [
  'nadiman0636indo@gmail.com', 
  'nadimanwar794@gmail.com', 
  'nadim841442@gmail.com'
];

interface AppContextType {
  user: User | null;
  settings: AppSettings;
  messages: ChatMessage[];
  mcqs: MCQQuestion[];
  notes: Note[];
  login: (email: string) => void;
  logout: () => void;
  updateSettings: (newSettings: AppSettings) => void;
  assignSubscription: (email: string, tier: SubscriptionTier, duration: DurationType) => void;
  deleteMessage: (msgId: string) => void;
  addNote: (note: Note) => void;
  deleteNote: (id: string) => void;
  addMCQ: (mcq: MCQQuestion) => void;
  setCredits: (email: string, amount: number) => void;
  importMCQs: (raw: string) => void;
  effectiveTier: SubscriptionTier;
}

const AppContext = createContext<AppContextType | null>(null);

const DEFAULT_SETTINGS: AppSettings = {
  pricing: {
    [SubscriptionTier.FREE]: {
      WEEKLY: { realPrice: 0, offerPrice: 0 },
      MONTHLY: { realPrice: 0, offerPrice: 0 },
      YEARLY: { realPrice: 0, offerPrice: 0 },
      LIFETIME: { realPrice: 0, offerPrice: 0 }
    },
    [SubscriptionTier.PREMIUM]: {
      WEEKLY: { realPrice: 499, offerPrice: 199 },
      MONTHLY: { realPrice: 1999, offerPrice: 599 },
      YEARLY: { realPrice: 9999, offerPrice: 3499 },
      LIFETIME: { realPrice: 24999, offerPrice: 9999 }
    },
    [SubscriptionTier.ULTRA]: {
      WEEKLY: { realPrice: 999, offerPrice: 499 },
      MONTHLY: { realPrice: 3999, offerPrice: 999 },
      YEARLY: { realPrice: 19999, offerPrice: 7999 },
      LIFETIME: { realPrice: 49999, offerPrice: 19999 }
    }
  },
  spinLimitPremium: 5,
  spinLimitUltra: 10,
  creditPerSpin: 10,
  creditPerGame: 50,
  universalChatLimitPerHour: 20,
  analysisCost: 30,
  analysisFreeForPremium: true,
  iicLabWebsiteUrl: "https://wikipedia.org",
  globalAd: {
    enabled: true,
    type: 'IMAGE',
    content: "https://picsum.photos/1200/400",
    showDefaultAdminAd: true
  },
  contentLocking: {
    freeNotes: false,
    premiumNotes: true,
    mcq: false,
    pdf: false,
    video: true
  },
  unlockConditions: {
    premiumMinutesRequired: 60,
    ultraMinutesRequired: 120,
    windowStartHour: 8,
    windowEndHour: 16
  }
};

const Signature = ({ className = "" }: { className?: string }) => (
  <div className={`text-[8px] font-black uppercase tracking-[0.2em] opacity-40 text-slate-500 mt-1 select-none ${className}`}>
    Developed by Nadim Anwar
  </div>
);

const Navbar = () => {
  const { user, logout, effectiveTier } = useContext(AppContext)!;
  const navigate = useNavigate();

  return (
    <nav className="bg-white/80 backdrop-blur-md border-b sticky top-0 z-50 px-6 h-16 flex items-center justify-between shadow-sm">
      <Link to="/" className="flex items-center gap-3">
        <div className="w-9 h-9 bg-slate-900 rounded-xl flex items-center justify-center text-white font-black text-sm shadow-xl pulse-premium">
          NA
        </div>
        <div className="flex flex-col">
          <span className="font-black text-sm tracking-tighter leading-none text-slate-900">NADIM PREMIUM</span>
          <Signature />
        </div>
      </Link>

      <div className="flex items-center gap-4">
        <div className="hidden sm:flex flex-col items-end">
          <span className="text-[10px] font-black text-slate-800 leading-none">{user?.name}</span>
          <div className={`text-[8px] px-2 py-0.5 rounded-full text-white font-black mt-1 uppercase ${
            effectiveTier === SubscriptionTier.ULTRA ? 'ultra-gradient' : 
            effectiveTier === SubscriptionTier.PREMIUM ? 'premium-gradient' : 'bg-slate-300'
          }`}>
            {effectiveTier} PLAN
          </div>
        </div>
        <button onClick={() => { logout(); navigate('/'); }} className="p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors">
          <LogOut size={18} />
        </button>
      </div>
    </nav>
  );
};

const AdminPanel = () => {
  const { settings, updateSettings, user, assignSubscription, setCredits, importMCQs } = useContext(AppContext)!;
  const [activeTab, setActiveTab] = useState<'USERS' | 'PRICING' | 'RULES' | 'LOCKS' | 'HUB' | 'IMPORT'>('USERS');
  const [targetEmail, setTargetEmail] = useState('');
  const [creditAmount, setCreditAmount] = useState(100);
  const [rawMCQ, setRawMCQ] = useState('');

  if (user?.role !== 'ADMIN') return <div className="p-20 text-center font-black text-red-500">UNAUTHORIZED ACCESS</div>;

  return (
    <div className="p-6 max-w-7xl mx-auto animate-in fade-in duration-500">
      <div className="mb-10">
        <h1 className="text-4xl font-black tracking-tighter flex items-center gap-4">
          <ShieldCheck className="text-red-500" size={40} />
          Admin HQ
        </h1>
        <Signature />
      </div>

      <div className="flex gap-2 mb-8 overflow-x-auto pb-4 no-scrollbar">
        {[
          { id: 'USERS', label: 'User Control', icon: <UserIcon size={14} /> },
          { id: 'PRICING', label: 'Plan Pricing', icon: <DollarSign size={14} /> },
          { id: 'RULES', label: 'Conditions', icon: <Clock size={14} /> },
          { id: 'LOCKS', label: 'Lockdowns', icon: <Lock size={14} /> },
          { id: 'HUB', label: 'Ads & Labs', icon: <FlaskConical size={14} /> },
          { id: 'IMPORT', label: 'Import MCQ', icon: <Database size={14} /> },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${
              activeTab === tab.id ? 'bg-slate-900 text-white shadow-xl scale-105' : 'bg-white text-slate-400 border border-slate-100 hover:bg-slate-50'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      <div className="bg-white p-12 rounded-[3.5rem] border border-slate-100 shadow-2xl space-y-12">
        {activeTab === 'USERS' && (
          <div className="space-y-12">
            <div className="bg-slate-50 p-8 rounded-3xl border border-slate-100">
              <h3 className="font-black text-sm uppercase tracking-widest text-slate-400 mb-8 flex items-center gap-2">
                <Crown size={18} className="text-indigo-600" /> Manual Subscription Bypass
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <input placeholder="Enter User Email" value={targetEmail} onChange={e => setTargetEmail(e.target.value)} className="p-4 rounded-xl border-none shadow-sm font-bold text-sm" />
                <select id="subTier" className="p-4 rounded-xl border-none shadow-sm font-bold text-sm bg-white">
                  <option value={SubscriptionTier.PREMIUM}>PREMIUM</option>
                  <option value={SubscriptionTier.ULTRA}>ULTRA</option>
                </select>
                <select id="subDur" className="p-4 rounded-xl border-none shadow-sm font-bold text-sm bg-white">
                  <option value="WEEKLY">WEEKLY</option>
                  <option value="MONTHLY">MONTHLY</option>
                  <option value="YEARLY">YEARLY</option>
                  <option value="LIFETIME">LIFETIME</option>
                </select>
                <button 
                  onClick={() => {
                    const tier = (document.getElementById('subTier') as HTMLSelectElement).value as SubscriptionTier;
                    const dur = (document.getElementById('subDur') as HTMLSelectElement).value as DurationType;
                    assignSubscription(targetEmail, tier, dur);
                    alert(`ACCESS GRANTED: ${tier} (${dur}) to ${targetEmail}`);
                  }}
                  className="bg-slate-900 text-white p-4 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl hover:bg-black transition-all"
                >
                  Confirm Assignment
                </button>
              </div>
            </div>

            <div className="bg-slate-50 p-8 rounded-3xl border border-slate-100">
              <h3 className="font-black text-sm uppercase tracking-widest text-slate-400 mb-8 flex items-center gap-2">
                <Database size={18} className="text-emerald-600" /> Coin Reserve Management
              </h3>
              <div className="flex flex-col md:flex-row gap-4">
                <input placeholder="User Email" value={targetEmail} onChange={e => setTargetEmail(e.target.value)} className="flex-1 p-4 rounded-xl border-none shadow-sm font-bold text-sm" />
                <input type="number" value={creditAmount} onChange={e => setCreditAmount(parseInt(e.target.value))} className="w-32 p-4 rounded-xl border-none shadow-sm font-bold text-sm" />
                <button 
                  onClick={() => {
                    setCredits(targetEmail, creditAmount);
                    alert(`CREDITS UPDATED FOR ${targetEmail}`);
                  }}
                  className="bg-emerald-600 text-white px-10 py-4 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-emerald-700"
                >
                  Update Balance
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'PRICING' && (
          <div className="space-y-12">
            <h3 className="font-black text-xl text-slate-900 border-b pb-6">Visual Store Pricing Manager</h3>
            {[SubscriptionTier.PREMIUM, SubscriptionTier.ULTRA].map(tier => (
              <div key={tier} className="bg-slate-50 p-8 rounded-3xl border border-slate-100">
                <div className="flex items-center gap-3 mb-8">
                  <div className={`w-3 h-3 rounded-full ${tier === 'ULTRA' ? 'bg-amber-500' : 'bg-indigo-600'}`}></div>
                  <h4 className="font-black text-sm uppercase tracking-[0.2em] text-slate-800">{tier} PRICING MATRIX</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {(['WEEKLY', 'MONTHLY', 'YEARLY', 'LIFETIME'] as DurationType[]).map(dur => (
                    <div key={dur} className="bg-white p-5 rounded-2xl shadow-sm space-y-4">
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{dur}</span>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <label className="text-[8px] font-bold text-slate-400">REAL PRICE</label>
                          <input 
                            type="number" 
                            value={settings.pricing[tier][dur].realPrice} 
                            onChange={e => {
                              const news = {...settings};
                              news.pricing[tier][dur].realPrice = parseInt(e.target.value);
                              updateSettings(news);
                            }}
                            className="w-20 p-1 text-right text-xs font-black bg-slate-50 rounded"
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <label className="text-[8px] font-bold text-emerald-500">OFFER PRICE</label>
                          <input 
                            type="number" 
                            value={settings.pricing[tier][dur].offerPrice} 
                            onChange={e => {
                              const news = {...settings};
                              news.pricing[tier][dur].offerPrice = parseInt(e.target.value);
                              updateSettings(news);
                            }}
                            className="w-20 p-1 text-right text-xs font-black bg-emerald-50 text-emerald-600 rounded"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'RULES' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="bg-slate-50 p-10 rounded-3xl border border-slate-100">
              <h3 className="font-black text-sm uppercase tracking-widest text-slate-400 mb-8 flex items-center gap-2">
                <Clock size={18} /> Usage Unlock Window
              </h3>
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase">Open Hour (8 AM = 8)</label>
                  <input type="number" value={settings.unlockConditions.windowStartHour} onChange={e => updateSettings({...settings, unlockConditions: {...settings.unlockConditions, windowStartHour: parseInt(e.target.value)}})} className="w-full p-4 rounded-xl border-none font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase">Close Hour (4 PM = 16)</label>
                  <input type="number" value={settings.unlockConditions.windowEndHour} onChange={e => updateSettings({...settings, unlockConditions: {...settings.unlockConditions, windowEndHour: parseInt(e.target.value)}})} className="w-full p-4 rounded-xl border-none font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase">Mins for Premium</label>
                  <input type="number" value={settings.unlockConditions.premiumMinutesRequired} onChange={e => updateSettings({...settings, unlockConditions: {...settings.unlockConditions, premiumMinutesRequired: parseInt(e.target.value)}})} className="w-full p-4 rounded-xl border-none font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase">Mins for Ultra</label>
                  <input type="number" value={settings.unlockConditions.ultraMinutesRequired} onChange={e => updateSettings({...settings, unlockConditions: {...settings.unlockConditions, ultraMinutesRequired: parseInt(e.target.value)}})} className="w-full p-4 rounded-xl border-none font-bold" />
                </div>
              </div>
            </div>

            <div className="bg-slate-50 p-10 rounded-3xl border border-slate-100 space-y-8">
              <h3 className="font-black text-sm uppercase tracking-widest text-slate-400 flex items-center gap-2">
                <PenTool size={18} /> Credits & Analysis
              </h3>
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase">Analysis Coin Cost</label>
                  <input type="number" value={settings.analysisCost} onChange={e => updateSettings({...settings, analysisCost: parseInt(e.target.value)})} className="w-full p-4 rounded-xl border-none font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase">Game Reward</label>
                  <input type="number" value={settings.creditPerGame} onChange={e => updateSettings({...settings, creditPerGame: parseInt(e.target.value)})} className="w-full p-4 rounded-xl border-none font-bold" />
                </div>
              </div>
              <div className="flex items-center justify-between p-4 bg-white rounded-2xl">
                <span className="font-black text-[10px]">Free Analysis for Premium?</span>
                <button onClick={() => updateSettings({...settings, analysisFreeForPremium: !settings.analysisFreeForPremium})} className={`px-4 py-2 rounded-lg font-black text-[10px] ${settings.analysisFreeForPremium ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-400'}`}>
                  {settings.analysisFreeForPremium ? 'ENABLED' : 'DISABLED'}
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'LOCKS' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <h3 className="col-span-full font-black text-sm uppercase tracking-widest text-slate-400 border-b pb-4 mb-4">Content Restrictions</h3>
            {Object.keys(settings.contentLocking).map((key) => (
              <div key={key} className="flex items-center justify-between p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
                <span className="capitalize font-black text-[10px] text-slate-700">{key.replace(/([A-Z])/g, ' $1')}</span>
                <button 
                  onClick={() => updateSettings({
                    ...settings, 
                    contentLocking: { ...settings.contentLocking, [key]: !((settings.contentLocking as any)[key]) }
                  })}
                  className={`px-6 py-2 rounded-xl font-black text-[9px] tracking-widest transition-all ${ (settings.contentLocking as any)[key] ? 'bg-red-500 text-white shadow-lg' : 'bg-emerald-500 text-white shadow-lg' }`}
                >
                  { (settings.contentLocking as any)[key] ? 'LOCKED' : 'OPEN' }
                </button>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'HUB' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="space-y-8 bg-slate-50 p-10 rounded-3xl">
              <h3 className="font-black text-sm uppercase tracking-widest text-slate-400">Advertisement Engine</h3>
              <div className="flex gap-2">
                {['IMAGE', 'VIDEO', 'TEXT'].map(t => (
                  <button key={t} onClick={() => updateSettings({...settings, globalAd: {...settings.globalAd, type: t as any}})} className={`flex-1 p-3 rounded-xl font-black text-[10px] ${settings.globalAd.type === t ? 'bg-slate-900 text-white' : 'bg-white text-slate-400 border border-slate-200'}`}>{t}</button>
                ))}
              </div>
              <input 
                placeholder="Google Drive Link / Ad Text" 
                value={settings.globalAd.content} 
                onChange={e => updateSettings({...settings, globalAd: {...settings.globalAd, content: e.target.value}})}
                className="w-full p-4 rounded-xl border-none shadow-inner font-bold text-sm bg-white"
              />
              <div className="flex items-center justify-between p-4 bg-white rounded-2xl">
                <span className="font-black text-[10px]">Show Admin Default Ad?</span>
                <input type="checkbox" checked={settings.globalAd.showDefaultAdminAd} onChange={e => updateSettings({...settings, globalAd: {...settings.globalAd, showDefaultAdminAd: e.target.checked}})} className="w-5 h-5 rounded" />
              </div>
            </div>

            <div className="space-y-8 bg-slate-50 p-10 rounded-3xl">
              <h3 className="font-black text-sm uppercase tracking-widest text-slate-400">IIC Lab Gateway</h3>
              <div className="space-y-4">
                <label className="text-[10px] font-black uppercase">Laboratory Website URL</label>
                <input value={settings.iicLabWebsiteUrl} onChange={e => updateSettings({...settings, iicLabWebsiteUrl: e.target.value})} className="w-full p-4 rounded-xl border-none shadow-sm font-bold text-sm bg-white" />
              </div>
              <div className="p-6 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-center gap-4">
                 <FlaskConical className="text-emerald-500" />
                 <p className="text-[10px] font-bold text-emerald-800 leading-relaxed uppercase">Students will see this website rendered inside the application Lab window.</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'IMPORT' && (
          <div className="space-y-8">
            <h3 className="font-black text-sm uppercase tracking-widest text-slate-400">Bulk MCQ Importer</h3>
            <p className="text-[9px] text-slate-400 font-bold uppercase border-l-4 border-indigo-600 pl-4">Format: Question|Option1|Option2|Option3|Option4|CorrectIndex(0-3)|Analysis1|Analysis2|Analysis3|Analysis4|Category</p>
            <textarea 
              rows={12} 
              value={rawMCQ}
              onChange={e => setRawMCQ(e.target.value)}
              placeholder="Example: What is the capital of France?|Berlin|Paris|Madrid|Rome|1|Berlin is Germany|Correct Answer|Madrid is Spain|Rome is Italy|Geography" 
              className="w-full p-8 rounded-[2.5rem] bg-slate-50 border-none font-mono text-xs focus:ring-4 focus:ring-slate-100"
            />
            <button 
              onClick={() => {
                importMCQs(rawMCQ);
                setRawMCQ('');
                alert("BATCH IMPORT SUCCESSFUL!");
              }}
              className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black text-xs uppercase tracking-[0.2em] shadow-2xl hover:bg-black transition-all"
            >
              Process Batch Import
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

const StorePage = () => {
  const { settings, effectiveTier } = useContext(AppContext)!;
  const plans = [
    { tier: SubscriptionTier.PREMIUM, color: 'indigo', icon: <Crown size={32} /> },
    { tier: SubscriptionTier.ULTRA, color: 'amber', icon: <PenTool size={32} /> }
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="text-center mb-20">
        <h2 className="text-6xl font-black tracking-tighter mb-4">Store Tiers</h2>
        <p className="text-slate-400 font-black uppercase text-[10px] tracking-widest">Premium Learning Investments</p>
        <Signature />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {plans.map(p => (
          <div key={p.tier} className="bg-white p-12 rounded-[4rem] border border-slate-50 shadow-2xl relative overflow-hidden group">
            <div className={`absolute top-0 right-0 w-32 h-32 opacity-5 rounded-full -mr-12 -mt-12 bg-${p.color}-600`}></div>
            <div className={`text-${p.color}-600 mb-8`}>{p.icon}</div>
            <h3 className={`text-5xl font-black mb-12 tracking-tighter`}>{p.tier} ACCESS</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {(['WEEKLY', 'MONTHLY', 'YEARLY', 'LIFETIME'] as DurationType[]).map(dur => {
                const price = settings.pricing[p.tier][dur];
                return (
                  <div key={dur} className="p-8 bg-slate-50 rounded-3xl hover:bg-slate-100 transition-all flex flex-col justify-between group/card">
                    <div>
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest block mb-4">{dur}</span>
                      <div className="flex flex-col gap-1">
                        <span className="text-slate-300 line-through text-sm font-bold">₹{price.realPrice}</span>
                        <div className="text-3xl font-black text-slate-900 leading-none">₹{price.offerPrice}</div>
                      </div>
                    </div>
                    <button className={`w-full py-4 rounded-2xl mt-8 font-black text-[10px] uppercase shadow-xl transition-all active:scale-95 ${
                      p.tier === 'ULTRA' ? 'ultra-gradient text-white' : 'premium-gradient text-white'
                    }`}>
                      Get Started
                    </button>
                    <Signature className="mt-4" />
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const MCQPage = () => {
  const { mcqs, settings, effectiveTier, user, setCredits } = useContext(AppContext)!;
  const [selectedMCQ, setSelectedMCQ] = useState<MCQQuestion | null>(null);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [answers, setAnswers] = useState<Record<string, number>>({});

  const isLocked = settings.contentLocking.mcq && effectiveTier === SubscriptionTier.FREE;

  if (isLocked) {
    return (
      <div className="p-20 text-center animate-in zoom-in duration-500">
        <Lock className="mx-auto text-slate-200 mb-8" size={80} />
        <h2 className="text-4xl font-black text-slate-900 mb-4 tracking-tighter uppercase">Exam Hub Locked</h2>
        <p className="text-slate-400 mb-10 font-bold uppercase text-[10px] tracking-[0.3em] leading-loose">Premium membership required<br/>to access the test center.</p>
        <Link to="/store" className="inline-block px-14 py-5 bg-slate-900 text-white rounded-[2rem] font-black shadow-2xl hover:scale-110 active:scale-95 transition-all uppercase text-[10px] tracking-widest">Upgrade to Access</Link>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-16 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-5xl font-black tracking-tighter flex items-center gap-4">
            <FileText className="text-indigo-600" size={48} />
            Test Library
          </h2>
          <Signature />
        </div>
        <div className="bg-white px-8 py-3 rounded-full shadow-sm text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 border border-slate-50">
          {mcqs.length} Professional Papers
        </div>
      </div>

      {!selectedMCQ ? (
        <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
          {mcqs.map((q) => (
            <div 
              key={q.id} 
              onClick={() => { setSelectedMCQ(q); setAnswers({}); setShowAnalysis(false); }}
              className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:border-indigo-500 cursor-pointer transition-all group flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-8">
                <span className="text-[10px] font-black uppercase tracking-widest bg-slate-900 text-white px-5 py-2 rounded-full">{q.category}</span>
                <Plus className="text-slate-100 group-hover:text-indigo-600 transition-colors" />
              </div>
              <h4 className="font-black text-2xl text-slate-800 leading-tight mb-10">{q.question}</h4>
              <div className="flex items-center justify-between pt-6 border-t border-slate-50">
                 <Signature />
                 <ChevronRight className="text-slate-200 group-hover:text-indigo-600" />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white p-14 rounded-[4rem] border border-slate-100 shadow-2xl animate-in slide-in-from-bottom duration-500 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-slate-50 rounded-full -mr-32 -mt-32 -z-0"></div>
          
          <button onClick={() => {setSelectedMCQ(null); setShowAnalysis(false);}} className="relative z-10 text-[10px] font-black text-slate-300 mb-12 hover:text-slate-900 flex items-center gap-2 uppercase tracking-widest transition-all">
            &larr; Return to Library
          </button>
          
          <div className="relative z-10 mb-14 border-l-[12px] border-slate-900 pl-10">
            <h3 className="text-4xl font-black text-slate-900 leading-tight mb-4">{selectedMCQ.question}</h3>
            <Signature />
          </div>
          
          <div className="relative z-10 space-y-5 mb-14">
            {selectedMCQ.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => setAnswers({...answers, [selectedMCQ.id]: idx})}
                className={`w-full p-8 rounded-3xl border-4 text-left transition-all flex items-center gap-8 group ${
                  answers[selectedMCQ.id] === idx ? 'border-slate-900 bg-slate-900 text-white shadow-2xl scale-[1.02]' : 'border-slate-50 bg-slate-50 hover:border-indigo-200 text-slate-600'
                }`}
              >
                <span className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black transition-colors shadow-sm text-lg ${
                  answers[selectedMCQ.id] === idx ? 'bg-white text-slate-900' : 'bg-white text-slate-300 group-hover:text-indigo-600'
                }`}>
                  {String.fromCharCode(65 + idx)}
                </span>
                <span className="font-black text-xl tracking-tight">{opt.text}</span>
              </button>
            ))}
          </div>

          <div className="relative z-10">
            <button 
              onClick={() => {
                if (effectiveTier === SubscriptionTier.FREE) {
                  if (confirm(`Unlock Expert Analysis for ${settings.analysisCost} coins?`)) {
                    if ((user?.credits || 0) >= settings.analysisCost) {
                      setCredits(user!.email, -settings.analysisCost);
                      setShowAnalysis(true);
                    } else {
                      alert("NOT ENOUGH COINS. VISIT STORE.");
                    }
                  }
                } else {
                  setShowAnalysis(true);
                }
              }}
              className={`w-full py-8 rounded-[2.5rem] font-black text-xl uppercase tracking-widest shadow-2xl transition-all ${
                showAnalysis ? 'bg-emerald-500 text-white' : 'bg-slate-900 text-white hover:scale-105 active:scale-95'
              }`}
            >
              {showAnalysis ? 'Deep Breakdown Active' : 'Show Expert Analysis'}
            </button>
          </div>

          {showAnalysis && (
            <div className="mt-20 p-12 bg-slate-50 rounded-[3.5rem] border border-slate-200 animate-in fade-in duration-1000 relative z-10">
              <h4 className="font-black text-slate-900 text-3xl mb-12 flex items-center gap-5">
                <BarChart3 size={48} className="text-indigo-600" />
                Solution Breakdown
              </h4>
              <div className="space-y-8">
                {selectedMCQ.options.map((opt, idx) => (
                  <div key={idx} className={`p-10 rounded-[3rem] border-4 ${opt.isCorrect ? 'bg-emerald-50 border-emerald-200 shadow-xl' : 'bg-white border-slate-100'}`}>
                    <div className="flex items-center gap-4 mb-6">
                      <span className="font-black text-[10px] uppercase tracking-[0.3em] text-slate-400">Choice {String.fromCharCode(65 + idx)}</span>
                      {opt.isCorrect && <span className="bg-emerald-600 text-white text-[9px] font-black px-4 py-1 rounded-full shadow-lg">Correct Answer</span>}
                    </div>
                    <p className="text-slate-800 font-bold leading-relaxed text-lg">{opt.analysis || "Comprehensive analysis pending for this choice."}</p>
                    <Signature className="mt-6 opacity-20" />
                  </div>
                ))}
              </div>
              <div className="mt-16 text-center">
                 <Signature />
                 <p className="text-[9px] font-black text-slate-300 mt-2">Verified Content Module</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const Dashboard = () => {
  const { settings, effectiveTier } = useContext(AppContext)!;
  return (
    <div className="p-6 space-y-10">
      {settings.globalAd.enabled && (
        <div className="w-full rounded-[3rem] overflow-hidden shadow-2xl border-4 border-white relative group animate-in slide-in-from-top duration-700">
          {settings.globalAd.type === 'IMAGE' ? (
            <img src={settings.globalAd.content} alt="Promotion" className="w-full h-64 object-cover" />
          ) : (
            <div className="bg-slate-900 p-16 text-white text-center italic font-black text-3xl">
              "{settings.globalAd.content}"
            </div>
          )}
          <div className="absolute top-6 right-6 bg-white/20 backdrop-blur-md px-6 py-2 rounded-full text-[10px] text-white font-black border border-white/20 uppercase tracking-widest">
            {settings.globalAd.showDefaultAdminAd ? 'Official Notice' : 'Promotion'}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-10 rounded-[3rem] shadow-sm border border-slate-50 flex flex-col justify-between group hover:shadow-2xl transition-all">
          <div className="relative">
            <Crown className="text-indigo-600 mb-6 group-hover:scale-110 transition-transform" size={32} />
            <h3 className="font-black text-[10px] uppercase tracking-[0.3em] text-slate-400">Current Status</h3>
          </div>
          <p className="text-5xl font-black text-slate-900 mt-6 tracking-tighter">{effectiveTier}</p>
          <Signature className="mt-6" />
        </div>
        <div className="bg-white p-10 rounded-[3rem] shadow-sm border border-slate-50 flex flex-col justify-between group hover:shadow-2xl transition-all">
          <div>
            <Gamepad2 className="text-amber-500 mb-6 group-hover:scale-110 transition-transform" size={32} />
            <h3 className="font-black text-[10px] uppercase tracking-[0.3em] text-slate-400">Daily Utility</h3>
          </div>
          <p className="text-5xl font-black text-slate-900 mt-6 tracking-tighter">
            {effectiveTier === SubscriptionTier.ULTRA ? settings.spinLimitUltra : 
             effectiveTier === SubscriptionTier.PREMIUM ? settings.spinLimitPremium : 1} Spins
          </p>
          <Signature className="mt-6" />
        </div>
        <div className="bg-white p-10 rounded-[3rem] shadow-sm border border-slate-50 flex flex-col justify-between relative overflow-hidden group hover:shadow-2xl transition-all">
          <div className="relative z-10">
            <Clock className="text-emerald-500 mb-6 group-hover:scale-110 transition-transform" size={32} />
            <h3 className="font-black text-[10px] uppercase tracking-[0.3em] text-slate-400">Daily Window</h3>
          </div>
          <p className="text-3xl font-black text-slate-900 mt-6 tracking-tighter z-10">
            {settings.unlockConditions.windowStartHour}:00 &mdash; {settings.unlockConditions.windowEndHour}:00
          </p>
          <div className="absolute bottom-0 right-0 w-24 h-24 bg-emerald-50 rounded-full -mr-12 -mb-12 opacity-50 group-hover:scale-150 transition-transform"></div>
          <Signature className="mt-6 z-10" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <Link to="/mcq" className="bg-white p-12 rounded-[4rem] border-4 border-slate-50 hover:border-indigo-500 hover:shadow-2xl transition-all group flex items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="w-20 h-20 rounded-[2.5rem] bg-slate-50 flex items-center justify-center text-slate-200 group-hover:bg-indigo-600 group-hover:text-white transition-all transform group-hover:rotate-12 shadow-inner">
              <FileText size={40} />
            </div>
            <div>
              <h4 className="font-black text-3xl text-slate-900 tracking-tighter uppercase mb-2">Weekly Test</h4>
              <p className="text-[10px] text-slate-400 font-black tracking-widest uppercase">Exam Simulator Module</p>
              <Signature />
            </div>
          </div>
          <ChevronRight className="text-slate-200 group-hover:text-indigo-600 group-hover:translate-x-3 transition-all" size={32} />
        </Link>
        <Link to="/notes" className="bg-white p-12 rounded-[4rem] border-4 border-slate-50 hover:border-purple-500 hover:shadow-2xl transition-all group flex items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="w-20 h-20 rounded-[2.5rem] bg-slate-50 flex items-center justify-center text-slate-200 group-hover:bg-purple-600 group-hover:text-white transition-all transform group-hover:rotate-12 shadow-inner">
              <BookOpen size={40} />
            </div>
            <div>
              <h4 className="font-black text-3xl text-slate-900 tracking-tighter uppercase mb-2">Premium Notes</h4>
              <p className="text-[10px] text-slate-400 font-black tracking-widest uppercase">AI Material & Video Hub</p>
              <Signature />
            </div>
          </div>
          <ChevronRight className="text-slate-200 group-hover:text-purple-600 group-hover:translate-x-3 transition-all" size={32} />
        </Link>
      </div>
    </div>
  );
};

const NotesPage = () => {
  const { notes, effectiveTier, settings, addNote } = useContext(AppContext)!;
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);

  const isLocked = settings.contentLocking.premiumNotes && effectiveTier === SubscriptionTier.FREE;

  const handleGenerate = async () => {
    if (!topic) return;
    setLoading(true);
    const content = await generatePremiumNote(topic);
    addNote({
      id: Math.random().toString(),
      title: topic,
      content,
      isPremium: true,
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
    });
    setLoading(false);
    setTopic('');
  };

  if (isLocked) {
    return (
      <div className="p-20 text-center">
        <Lock className="mx-auto text-slate-200 mb-10" size={80} />
        <h2 className="text-4xl font-black text-slate-900 mb-4 tracking-tighter uppercase">Notes Locked</h2>
        <p className="text-slate-400 mb-10 font-bold uppercase text-[10px] tracking-[0.3em]">Subscriber Level Access Required</p>
        <Link to="/store" className="inline-block px-14 py-5 bg-purple-600 text-white rounded-[2rem] font-black shadow-2xl hover:scale-110 active:scale-95 transition-all text-[10px] tracking-widest uppercase">Unlock Library</Link>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-20 gap-10">
        <div>
          <h2 className="text-6xl font-black tracking-tighter flex items-center gap-5">
            <BookOpen className="text-purple-600" size={56} />
            Premium Notes
          </h2>
          <Signature />
        </div>
        <div className="flex gap-4 w-full lg:w-auto">
          <input 
            value={topic}
            onChange={e => setTopic(e.target.value)}
            placeholder="Search Research Topic..." 
            className="flex-1 lg:w-96 p-6 rounded-[2.5rem] bg-white border-none shadow-2xl focus:ring-4 focus:ring-purple-100 font-black text-sm"
          />
          <button 
            onClick={handleGenerate}
            disabled={loading}
            className="w-20 h-20 lg:w-auto lg:px-12 bg-slate-900 text-white font-black rounded-full lg:rounded-[2.5rem] shadow-2xl hover:bg-black disabled:opacity-50 transition-all flex items-center justify-center gap-4"
          >
            {loading ? <div className="w-6 h-6 border-4 border-white border-t-transparent animate-spin rounded-full"></div> : <Plus size={24} />}
            <span className="hidden lg:inline">GENERATE</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-16">
        {notes.map(note => (
          <div key={note.id} className="bg-white rounded-[4rem] overflow-hidden border-2 border-slate-50 shadow-sm hover:shadow-2xl transition-all group">
            <div className="aspect-video bg-slate-100 relative group-hover:scale-[1.03] transition-transform duration-1000">
              {note.videoUrl ? (
                <iframe 
                  className="w-full h-full" 
                  src={note.videoUrl} 
                  title="Note Video" 
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-slate-200">
                  <Video size={64} />
                  <span className="text-[10px] font-black mt-6 uppercase tracking-[0.3em]">No Video Linked</span>
                </div>
              )}
              <div className="absolute top-10 right-10 px-6 py-3 bg-slate-900/90 backdrop-blur rounded-full text-[10px] font-black text-white shadow-2xl uppercase tracking-widest">
                PREMIUM MODULE
              </div>
            </div>
            <div className="p-16">
              <h4 className="text-4xl font-black mb-8 text-slate-900 tracking-tighter leading-none">{note.title}</h4>
              <div className="text-slate-600 text-xl prose max-w-none mb-12 leading-relaxed font-bold opacity-80">
                {note.content}
              </div>
              <div className="pt-10 border-t flex items-center justify-between">
                <Signature />
                <div className="flex items-center gap-2">
                   <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                   <span className="text-[9px] font-black uppercase text-slate-300 tracking-widest">Verified by Admin</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const IICLab = () => {
  const { settings } = useContext(AppContext)!;
  return (
    <div className="p-6 h-[calc(100vh-160px)] flex flex-col max-w-7xl mx-auto">
      <div className="mb-12 text-center lg:text-left">
        <h2 className="text-6xl font-black tracking-tighter flex items-center gap-5 justify-center lg:justify-start">
          <FlaskConical className="text-emerald-500" size={64} />
          IIC Lab Center
        </h2>
        <Signature />
      </div>
      <div className="flex-1 bg-white rounded-[4.5rem] border-[16px] border-white overflow-hidden shadow-2xl relative">
        <iframe 
          src={settings.iicLabWebsiteUrl} 
          className="w-full h-full"
          title="Lab Terminal"
        />
        <div className="absolute bottom-10 right-10 flex gap-4">
           <div className="px-8 py-4 bg-slate-900 text-white text-[10px] font-black rounded-full shadow-2xl uppercase tracking-[0.3em] border border-white/10">Secure Laboratory Shell Active</div>
           <div className="px-8 py-4 bg-emerald-500 text-white text-[10px] font-black rounded-full shadow-2xl uppercase tracking-[0.3em]">{settings.iicLabWebsiteUrl.split('/')[2]}</div>
        </div>
      </div>
    </div>
  );
};

const ChatPage = () => {
  const { messages, user, settings, deleteMessage } = useContext(AppContext)!;
  const [text, setText] = useState('');

  return (
    <div className="p-6 h-[calc(100vh-160px)] flex flex-col max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-12">
        <div>
          <h2 className="text-6xl font-black tracking-tighter flex items-center gap-6">
            <MessageSquare className="text-indigo-600" size={56} />
            Global Hub
          </h2>
          <Signature />
        </div>
        <div className="px-10 py-4 bg-slate-900 text-white rounded-full text-[10px] font-black uppercase tracking-[0.3em] shadow-2xl border border-white/10">
          Capacity: {settings.universalChatLimitPerHour}/HR
        </div>
      </div>

      <div className="flex-1 bg-white rounded-[4.5rem] border-[12px] border-white shadow-2xl overflow-y-auto p-14 space-y-10 mb-10 no-scrollbar">
        {messages.map(m => (
          <div key={m.id} className={`flex flex-col ${m.senderEmail === user?.email ? 'items-end' : 'items-start'}`}>
            <div className="flex items-center gap-4 mb-3 px-6">
              <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em]">{m.senderName}</span>
              {user?.role === 'ADMIN' && (
                <button onClick={() => deleteMessage(m.id)} className="p-2.5 bg-red-50 text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition-all shadow-sm">
                  <Trash2 size={16} />
                </button>
              )}
            </div>
            <div className={`px-12 py-6 rounded-[3.5rem] text-xl max-w-[85%] font-black shadow-sm ${
              m.senderEmail === user?.email ? 'bg-slate-900 text-white rounded-tr-none' : 'bg-slate-50 text-slate-700 rounded-tl-none border border-slate-100 shadow-inner'
            }`}>
              {m.text}
            </div>
            <Signature className="mt-2 mr-6" />
          </div>
        ))}
      </div>

      <div className="flex gap-4 p-4 bg-white rounded-[4rem] border border-slate-50 shadow-2xl">
        <input 
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="Broadcast to the Premium Community..." 
          className="flex-1 px-12 py-6 bg-transparent border-none focus:ring-0 font-black text-2xl placeholder:text-slate-200"
        />
        <button 
          onClick={() => {
            alert("Sent to Hub Feed!");
            setText('');
          }}
          className="w-24 h-24 bg-slate-900 text-white rounded-full flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all"
        >
          <ChevronRight size={48} />
        </button>
      </div>
    </div>
  );
};

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const { login } = useContext(AppContext)!;

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-[#0a0f1a] relative overflow-hidden">
      <div className="absolute top-0 -left-1/4 w-full h-full bg-indigo-600/5 rounded-full blur-[180px] animate-pulse"></div>
      <div className="absolute bottom-0 -right-1/4 w-full h-full bg-purple-600/5 rounded-full blur-[180px] animate-pulse"></div>

      <div className="bg-white/95 backdrop-blur-3xl w-full max-w-3xl p-24 rounded-[6rem] shadow-2xl border border-white/20 relative z-10 animate-in zoom-in-95 duration-1000">
        <div className="flex flex-col items-center mb-20 text-center">
          <div className="w-28 h-28 bg-slate-900 rounded-[3rem] flex items-center justify-center text-white text-6xl font-black mb-12 shadow-[0_40px_80px_-15px_rgba(0,0,0,0.6)] transform hover:rotate-12 transition-transform duration-700">
            NA
          </div>
          <h1 className="text-6xl font-black tracking-tighter text-slate-900 mb-2">NADIM PREMIUM</h1>
          <p className="text-slate-400 font-black uppercase tracking-[0.5em] text-[10px]">The Future of Digital Learning</p>
          <Signature className="mt-4" />
        </div>

        <div className="space-y-12">
          <div>
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-5 block px-6">Access Credentials</label>
            <input 
              type="email" 
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="Enter Registered Email..." 
              className="w-full p-10 rounded-[3.5rem] bg-slate-50 border-4 border-transparent focus:border-slate-900 focus:bg-white focus:ring-0 text-3xl font-black transition-all shadow-inner placeholder:text-slate-200"
            />
          </div>
          <button 
            onClick={() => login(email)}
            className="w-full py-10 bg-slate-900 text-white rounded-[3.5rem] font-black text-3xl shadow-[0_30px_60px_rgba(0,0,0,0.4)] hover:bg-black transition-all active:scale-95 transform hover:-translate-y-3"
          >
            LOGIN SECURELY
          </button>
        </div>

        <div className="mt-20 text-center border-t border-slate-100 pt-12">
          <Signature />
          <div className="flex justify-center gap-16 mt-8 text-slate-200 font-black text-[10px] uppercase tracking-[0.3em]">
             <span className="hover:text-slate-900 cursor-pointer transition-colors">Security</span>
             <span className="hover:text-slate-900 cursor-pointer transition-colors">Privacy</span>
             <span className="hover:text-slate-900 cursor-pointer transition-colors">Hub</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [notes, setNotes] = useState<Note[]>([]);
  const [mcqs, setMcqs] = useState<MCQQuestion[]>([
    {
      id: 'q1',
      category: 'UI/UX Engineering',
      question: 'Which element defines a premium "bespoke" experience?',
      options: [
        { text: 'Custom Micro-interactions', isCorrect: true, analysis: 'Micro-interactions provide immediate, high-quality feedback that feels custom-tailored to the user.' },
        { text: 'Standard System Fonts', isCorrect: false, analysis: 'System fonts feel default and mass-produced, lacking the exclusive feel of custom typography.' },
        { text: 'Stock Photography', isCorrect: false, analysis: 'Stock assets are generic and can be found on many low-end sites, reducing perceived value.' },
        { text: 'Minimal Spacing', isCorrect: false, analysis: 'Tight spacing feels crowded and cheap. Luxury design utilizes white space as a premium resource.' }
      ]
    }
  ]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const effectiveTier = useMemo(() => {
    if (!user) return SubscriptionTier.FREE;
    if (user.subscription.manualAssignment) return user.subscription.tier;

    const now = new Date();
    const hour = now.getHours();
    const { windowStartHour, windowEndHour, premiumMinutesRequired, ultraMinutesRequired } = settings.unlockConditions;

    if (hour >= windowStartHour && hour < windowEndHour) {
      if (user.usageTimeYesterday >= ultraMinutesRequired) return SubscriptionTier.ULTRA;
      if (user.usageTimeYesterday >= premiumMinutesRequired) return SubscriptionTier.PREMIUM;
    }

    return SubscriptionTier.FREE;
  }, [user, settings.unlockConditions]);

  const login = (email: string) => {
    const isAdmin = ADMIN_EMAILS.includes(email.toLowerCase());
    setUser({
      id: 'u-' + Date.now(),
      email: email.toLowerCase(),
      name: email.split('@')[0].toUpperCase(),
      role: isAdmin ? 'ADMIN' : 'USER',
      subscription: {
        tier: SubscriptionTier.FREE,
        duration: 'NONE',
        manualAssignment: false
      },
      credits: 2000,
      usageTimeYesterday: 140, // Mocked usage for auto-unlock
      dailyLogin: true
    });
  };

  const logout = () => setUser(null);

  const importMCQs = (raw: string) => {
    const lines = raw.split('\n').filter(l => l.trim().includes('|'));
    const newMcqs: MCQQuestion[] = lines.map((line, i) => {
      const parts = line.split('|');
      const [q, o1, o2, o3, o4, correct, a1, a2, a3, a4, cat] = parts;
      return {
        id: `imp-${Date.now()}-${i}`,
        question: q,
        category: cat || 'Admin Import',
        options: [
          { text: o1, isCorrect: correct === '0', analysis: a1 },
          { text: o2, isCorrect: correct === '1', analysis: a2 },
          { text: o3, isCorrect: correct === '2', analysis: a3 },
          { text: o4, isCorrect: correct === '3', analysis: a4 },
        ]
      };
    });
    setMcqs(prev => [...newMcqs, ...prev]);
  };

  const contextValue: AppContextType = {
    user, settings, messages, mcqs, notes, login, logout, 
    updateSettings: setSettings,
    assignSubscription: (email, tier, duration) => {
      if (user?.email === email.toLowerCase()) {
        setUser({ ...user, subscription: { tier, duration, manualAssignment: true } });
      }
    },
    deleteMessage: (id) => setMessages(messages.filter(m => m.id !== id)),
    addNote: (note) => setNotes([note, ...notes]),
    deleteNote: (id) => setNotes(notes.filter(n => n.id !== id)),
    addMCQ: (mcq) => setMcqs([mcq, ...mcqs]),
    effectiveTier,
    setCredits: (email, amount) => {
      if (user?.email === email.toLowerCase()) {
        setUser({ ...user, credits: Math.max(0, user.credits + amount) });
      }
    },
    importMCQs
  };

  if (!user) return <AppContext.Provider value={contextValue}><LoginPage /></AppContext.Provider>;

  return (
    <AppContext.Provider value={contextValue}>
      <Router>
        <div className="min-h-screen flex flex-col bg-slate-50">
          <Navbar />
          <div className="flex-1 flex flex-col lg:flex-row">
            <aside className="w-full lg:w-96 bg-white border-r p-12 space-y-4 hidden lg:block shadow-sm">
              <SidebarContent />
            </aside>
            <main className="flex-1 overflow-y-auto bg-slate-50/30">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/mcq" element={<MCQPage />} />
                <Route path="/notes" element={<NotesPage />} />
                <Route path="/chat" element={<ChatPage />} />
                <Route path="/iic" element={<IICLab />} />
                <Route path="/store" element={<StorePage />} />
                <Route path="/admin" element={<AdminPanel />} />
              </Routes>
            </main>
          </div>
          
          <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t px-10 py-6 flex justify-around items-center z-50 shadow-[0_-20px_50px_rgba(0,0,0,0.1)] rounded-t-[4rem]">
            <MobileNavItem to="/" icon={<LayoutDashboard size={26} />} />
            <MobileNavItem to="/notes" icon={<BookOpen size={26} />} />
            <MobileNavItem to="/mcq" icon={<FileText size={26} />} />
            <MobileNavItem to="/store" icon={<ShoppingCart size={26} />} />
          </div>
        </div>
      </Router>
    </AppContext.Provider>
  );
}

function SidebarContent() {
  const { user, effectiveTier } = useContext(AppContext)!;
  return (
    <div className="space-y-3">
      <NavItem to="/" icon={<LayoutDashboard size={20} />} label="Dashboard" />
      <NavItem to="/notes" icon={<BookOpen size={20} />} label="Premium Notes" />
      <NavItem to="/mcq" icon={<FileText size={20} />} label="Test Center" />
      <NavItem to="/chat" icon={<MessageSquare size={20} />} label="Universal Hub" />
      <NavItem to="/iic" icon={<FlaskConical size={20} />} label="Research Lab" />
      <NavItem to="/store" icon={<ShoppingCart size={20} />} label="Premium Store" />
      
      <div className="pt-16 mt-16 border-t border-slate-100 space-y-10">
        {user?.role === 'ADMIN' && (
          <NavItem to="/admin" icon={<ShieldCheck size={20} className="text-red-500" />} label="Command Center" />
        )}
        
        <div className="p-12 bg-slate-900 rounded-[3.5rem] shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-12 -mt-12 transition-transform group-hover:scale-110"></div>
          <div className="flex items-center gap-2 mb-4 relative z-10">
            <Crown size={20} className="text-amber-400" />
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">User Wallet</span>
          </div>
          <div className="text-5xl font-black text-white tracking-tighter relative z-10">{user?.credits || 0}</div>
          <p className="text-[10px] text-slate-500 font-black mt-4 uppercase tracking-[0.2em]">Coins Active</p>
          <Signature className="mt-8" />
        </div>

        <div className="flex flex-col items-center gap-2 opacity-30">
           <Signature />
           <p className="text-[7px] font-black uppercase tracking-widest text-slate-300">Nadim EdTech Protocol v4.0</p>
        </div>
      </div>
    </div>
  );
}

function NavItem({ to, icon, label }: { to: string, icon: React.ReactNode, label: string }) {
  const location = useLocation();
  const isActive = location.pathname === to;
  return (
    <Link 
      to={to} 
      className={`flex items-center gap-6 px-10 py-5 rounded-[2rem] font-black transition-all ${
        isActive ? 'bg-slate-900 text-white shadow-2xl scale-105' : 'text-slate-400 hover:bg-slate-50 hover:text-slate-900'
      }`}
    >
      {icon}
      <span className="text-xs tracking-tight uppercase tracking-widest">{label}</span>
    </Link>
  );
}

function MobileNavItem({ to, icon }: { to: string, icon: React.ReactNode }) {
  const location = useLocation();
  const isActive = location.pathname === to;
  return (
    <Link to={to} className={`p-5 rounded-2xl transition-all ${isActive ? 'bg-slate-900 text-white shadow-xl scale-110' : 'text-slate-200'}`}>
      {icon}
    </Link>
  );
}
