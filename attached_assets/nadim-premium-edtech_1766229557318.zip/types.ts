
export enum SubscriptionTier {
  FREE = 'FREE',
  PREMIUM = 'PREMIUM',
  ULTRA = 'ULTRA'
}

export type DurationType = 'WEEKLY' | 'MONTHLY' | 'YEARLY' | 'LIFETIME';

export interface PlanPricing {
  realPrice: number;
  offerPrice: number;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'ADMIN' | 'USER';
  subscription: {
    tier: SubscriptionTier;
    duration: DurationType | 'NONE';
    expiresAt?: string;
    manualAssignment: boolean;
  };
  credits: number;
  usageTimeYesterday: number; // minutes
  dailyLogin: boolean;
}

export interface MCQOption {
  text: string;
  isCorrect: boolean;
  analysis: string;
}

export interface MCQQuestion {
  id: string;
  question: string;
  options: MCQOption[];
  category: string;
}

export interface AppSettings {
  // Store Pricing - Managed by Admin
  pricing: Record<SubscriptionTier, Record<DurationType, PlanPricing>>;
  
  // Game & Spin Limits
  spinLimitPremium: number;
  spinLimitUltra: number;
  creditPerSpin: number;
  creditPerGame: number;
  
  // App Logic
  universalChatLimitPerHour: number;
  analysisCost: number;
  analysisFreeForPremium: boolean;

  // IIC Lab & Advertisements
  iicLabWebsiteUrl: string;
  globalAd: {
    enabled: boolean;
    type: 'IMAGE' | 'VIDEO' | 'TEXT';
    content: string; // URL or Text
    showDefaultAdminAd: boolean;
  };

  // Content Visibility (Locking)
  contentLocking: {
    freeNotes: boolean;
    premiumNotes: boolean;
    mcq: boolean;
    pdf: boolean;
    video: boolean;
  };

  // Usage-based Unlocking Rules
  unlockConditions: {
    premiumMinutesRequired: number;
    ultraMinutesRequired: number;
    windowStartHour: number; // e.g., 8
    windowEndHour: number;   // e.g., 16
  };
}

export interface ChatMessage {
  id: string;
  senderEmail: string;
  senderName: string;
  text: string;
  timestamp: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  isPremium: boolean;
  videoUrl?: string;
}
